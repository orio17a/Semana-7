import { useEffect, useState } from "react";
import type { Materia } from "../types/Materia";
import type { Carrera } from "../types/Carrera";
import type { Profesor } from "../types/Profesor";
import {
  createMateria,
  updateMateria,
  type CreateMateriaRequest,
  type UpdateMateriaRequest,
} from "../services/materiaService";
import { getCarreras } from "../services/carreraService";
import { getProfesores } from "../services/profesorService";

interface Props {
  materiaEditar?: Materia | null;
  onGuardado: () => void;
  onCancelarEdicion: () => void;
}

export default function MateriaForm({
  materiaEditar,
  onGuardado,
  onCancelarEdicion,
}: Props) {
  const [nombre, setNombre] = useState("");
  const [codigo, setCodigo] = useState("");
  const [anio, setAnio] = useState(1);
  const [carreraId, setCarreraId] = useState("");
  const [profesorId, setProfesorId] = useState("");
  const [activa, setActiva] = useState(true);

  const [carreras, setCarreras] = useState<Carrera[]>([]);
  const [profesores, setProfesores] = useState<Profesor[]>([]);
  const [cargandoOpciones, setCargandoOpciones] = useState(true);

  useEffect(() => {
    cargarOpciones();
  }, []);

  useEffect(() => {
    if (materiaEditar) {
      setNombre(materiaEditar.nombre);
      setCodigo(materiaEditar.codigo);
      setAnio(materiaEditar.anio);
      setCarreraId(materiaEditar.carreraId);
      setProfesorId(materiaEditar.profesorId ?? "");
      setActiva(materiaEditar.activa);
    } else {
      limpiarFormulario();
    }
  }, [materiaEditar]);

  async function cargarOpciones() {
    try {
      setCargandoOpciones(true);

      const [carrerasData, profesoresData] = await Promise.all([
        getCarreras(),
        getProfesores(),
      ]);

      setCarreras(carrerasData.filter((carrera) => carrera.activa));
      setProfesores(profesoresData.filter((profesor) => profesor.activo));
    } catch (error) {
      console.error("Error cargando carreras/profesores:", error);
    } finally {
      setCargandoOpciones(false);
    }
  }

  function limpiarFormulario() {
    setNombre("");
    setCodigo("");
    setAnio(1);
    setCarreraId("");
    setProfesorId("");
    setActiva(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!carreraId) {
      alert("Tenés que seleccionar una carrera");
      return;
    }

    try {
      if (materiaEditar) {
        const materiaActualizada: UpdateMateriaRequest = {
          nombre,
          codigo,
          anio,
          activa,
          carreraId,
          profesorId: profesorId || null,
        };

        await updateMateria(materiaEditar.id, materiaActualizada);
      } else {
        const nuevaMateria: CreateMateriaRequest = {
          nombre,
          codigo,
          anio,
          carreraId,
          profesorId: profesorId || null,
        };

        await createMateria(nuevaMateria);
      }

      limpiarFormulario();
      onGuardado();
    } catch (error) {
      console.error(error);

      alert(
        materiaEditar
          ? "No se pudo actualizar la materia"
          : "No se pudo crear la materia"
      );
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>{materiaEditar ? "Editar materia" : "Nueva materia"}</h2>

      <div className="form-grid">
        <div className="form-group">
          <label>Nombre</label>
          <input
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Código</label>
          <input
            value={codigo}
            onChange={(e) => setCodigo(e.target.value)}
            placeholder="Ej: PROG-01"
            required
          />
        </div>

        <div className="form-group">
          <label>Año</label>
          <input
            type="number"
            min="1"
            value={anio}
            onChange={(e) => setAnio(Number(e.target.value))}
            required
          />
        </div>

        <div className="form-group">
          <label>Carrera</label>
          <select
            value={carreraId}
            onChange={(e) => setCarreraId(e.target.value)}
            required
            disabled={cargandoOpciones}
          >
            <option value="">
              {cargandoOpciones ? "Cargando..." : "Seleccionar carrera"}
            </option>

            {carreras.map((carrera) => (
              <option key={carrera.id} value={carrera.id}>
                {carrera.nombre}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Profesor</label>
          <select
            value={profesorId}
            onChange={(e) => setProfesorId(e.target.value)}
            disabled={cargandoOpciones}
          >
            <option value="">Sin profesor asignado</option>

            {profesores.map((profesor) => (
              <option key={profesor.id} value={profesor.id}>
                {profesor.apellido}, {profesor.nombre}
              </option>
            ))}
          </select>
        </div>
      </div>

      {materiaEditar && (
        <div className="form-group">
          <label>
            <input
              type="checkbox"
              checked={activa}
              onChange={(e) => setActiva(e.target.checked)}
            />
            Activa
          </label>
        </div>
      )}

      <div className="form-actions">
        <button className="btn btn-primary" type="submit">
          {materiaEditar ? "Actualizar materia" : "Guardar materia"}
        </button>

        {materiaEditar && (
          <button
            className="btn btn-secondary"
            type="button"
            onClick={() => {
              limpiarFormulario();
              onCancelarEdicion();
            }}
          >
            Cancelar
          </button>
        )}
      </div>
    </form>
  );
}
