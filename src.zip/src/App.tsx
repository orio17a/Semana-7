import { useState } from "react";
import {
  BrowserRouter,
  NavLink,
  Route,
  Routes,
} from "react-router-dom";
import ProfesoresPage from "./pages/ProfesoresPage";
import MateriasPage from "./pages/MateriasPage";
import AlumnosPage from "./pages/AlumnosPage";
import CarrerasPage from "./pages/CarrerasPage";
import "./index.css";

function App() {
  const [menuColapsado, setMenuColapsado] = useState(false);

  return (
    <BrowserRouter>
      <div className="app-shell">
        <aside className={`sidebar ${menuColapsado ? "collapsed" : ""}`}>
          <div className="sidebar-top">
            {!menuColapsado && (
              <div className="brand">
                <h2>Tercceros</h2>
                <span>Gestión Académica</span>
              </div>
            )}

            <button
              className="collapse-button"
              onClick={() => setMenuColapsado(!menuColapsado)}
              title={menuColapsado ? "Abrir menú" : "Cerrar menú"}
            >
              {menuColapsado ? "→" : "←"}
            </button>
          </div>

          <nav className="menu">
            <NavLink
              to="/alumnos"
              className={({ isActive }) =>
                `menu-item ${isActive ? "active" : ""}`
              }
            >
              <span className="menu-icon">👨‍🎓</span>
              {!menuColapsado && <span>Alumnos</span>}
            </NavLink>

            <NavLink
              to="/carreras"
              className={({ isActive }) =>
                `menu-item ${isActive ? "active" : ""}`
              }
            >
              <span className="menu-icon">🎓</span>
              {!menuColapsado && <span>Carreras</span>}
            </NavLink>

            <NavLink
              to="/profesores"
              className={({ isActive }) =>
                `menu-item ${isActive ? "active" : ""}`
              }
            >
              <span className="menu-icon">👨‍🏫</span>
              {!menuColapsado && <span>Profesores</span>}
            </NavLink>

            <NavLink
              to="/materias"
              className={({ isActive }) =>
                `menu-item ${isActive ? "active" : ""}`
              }
            >
              <span className="menu-icon">📚</span>
              {!menuColapsado && <span>Materias</span>}
            </NavLink>
          </nav>
        </aside>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<AlumnosPage />} />
            <Route path="/alumnos" element={<AlumnosPage />} />
            <Route path="/carreras" element={<CarrerasPage />} />

            <Route
  path="/profesores"
  element={<ProfesoresPage />}
/>

            <Route path="/materias" element={<MateriasPage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;