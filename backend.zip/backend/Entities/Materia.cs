namespace backend.Entities;

public class Materia
{
    public Guid Id { get; set; }

    public string Nombre { get; set; } = string.Empty;

    public string Codigo { get; set; } = string.Empty;

    public int Anio { get; set; }

    public bool Activa { get; set; } = true;

    public Guid CarreraId { get; set; }

    public Carrera Carrera { get; set; } = null!;

    public Guid? ProfesorId { get; set; }

    public Profesor? Profesor { get; set; }
}