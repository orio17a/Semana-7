namespace backend.DTOs.Materias;

public class CreateMateriaDto
{
    public string Nombre { get; set; } = string.Empty;

    public string Codigo { get; set; } = string.Empty;

    public int Anio { get; set; }

    public Guid CarreraId { get; set; }

    public Guid? ProfesorId { get; set; }
}