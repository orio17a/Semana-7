namespace backend.DTOs.Materias;

public class UpdateMateriaDto
{
    public string Nombre { get; set; } = string.Empty;

    public string Codigo { get; set; } = string.Empty;

    public int Anio { get; set; }

    public bool Activa { get; set; }

    public Guid CarreraId { get; set; }

    public Guid? ProfesorId { get; set; }
}